import type { Metadata } from "next";
import { Plus_Jakarta_Sans, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
  display: "swap",
});

const space = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Ohboy Consultancy | Bridging Hardware, Software, and AI",
  description:
    "Technical consulting for product companies. 20+ years experience delivering mission-critical systems for Olympics, FIFA World Cup, Wimbledon. AI/ML, Embedded Systems, Full-Stack Development.",
  keywords: [
    "technical consulting",
    "AI consulting",
    "embedded systems",
    "software architecture",
    "Dubai",
    "fractional CTO",
  ],
  authors: [{ name: "Aravind Vijayakumar" }],
  creator: "Ohboy Consultancy FZ LLC",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://ohboyconsultancy.com",
    siteName: "Ohboy Consultancy",
    title: "Ohboy Consultancy | Bridging Hardware, Software, and AI",
    description:
      "Technical consulting for product companies. Delivering mission-critical systems with grit and first-principles thinking.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${jakarta.variable} ${space.variable} ${jetbrains.variable} font-sans antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
